from project.car import Car


class SportsCar(Car):

    @staticmethod
    def race():
        return "racing..."
