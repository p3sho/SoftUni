from project.fruit import Fruit

f = Fruit('orange', '2024-01-6')
print(f.name)